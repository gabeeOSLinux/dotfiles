#!/bin/bash

yad --width=800 --height=700 \
--center \
--title="Keybindings" \
--no-buttons \
--list \
--column=Key: \
--column=Description: \
--column=Command: \
--timeout=60 \
--timeout-indicator=bottom \
"ESC" "close this app" "" "=" "SUPER KEY" "(SUPER KEY)" \
" T" "Terminal" "(kitty)" \
" A" "App Launcher" "(rofi)" \
" E" "Open File Manager" "(Dolphin)" \
" Q   " "close focused app" "(kill)" \
" V" "Clipboard Manager" "(cliphist)" \
" O" "power-menu" "(wlogout)" \
" Shift W" "Choose wallpaper" "(swww)" \
" Print" "screenshot" "(grim)" \
" P" "screenshot region" "(click on a window to print it)" \
" ALT P" "print focused monitor" "(grim)" \
" Del" "Hyprland Exit" "(SAVE YOUR WORK!!!)" \
"ALT Return" "Fullscreen" "Toggles to full screen" \
" J" "Toggle Dwindle | Master Layout" "Hyprland Layout" \
" W" "Toggle float" "single window" \
" G" "Toggle all windows to float" "all windows" \
" ALT G" "Gamemode! All animations off" "" \
" H" "Launch this app" "" \
"" "" "" \
"" "This window will auto-close in 60 secs" ""\
