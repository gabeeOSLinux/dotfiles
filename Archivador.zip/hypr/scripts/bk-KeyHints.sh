#!/bin/bash

yad --width=700 --height=700 \
--center \
--title="Keybindings" \
--no-buttons \
--list \
--column=Key: \
--column=Description: \
--column=Command: \
--timeout=60 \
--timeout-indicator=bottom \
"ESC" "close this app" "" "=" "SUPER KEY" "(SUPER KEY)" \
" T" "Terminal" "(kitty)" \
" A" "App Launcher" "(rofi)" \
" E" "Open File Manager" "(Dolphin)" \
" Q   " "close focused app" "(kill)" \
" V" "Clipboard Manager" "(cliphist)" \
" Shift W" "Choose wallpaper" "(swww)" \
"CTRL ALT W" "Random wallpaper" "(swww)" \
"CTRL W" "Choose waybar styles" "(waybar styles)" \
"ALT W" "Choose waybar layout" "(waybar layout)" \
"CTRL SHIFT W" "Reload Waybar and Dunst" "" \
" Print" "screenshot" "(grim)" \
" Shift Print" "screenshot region" "(grim + slurp)" \
" Shift S" "screenshot region" "(swappy)" \
" O" "power-menu" "(wlogout)" \
"CTRL ALT L" "screen lock" "(swaylock)" \
"CTRL ALT Del" "Hyprland Exit" "(SAVE YOUR WORK!!!)" \
" F" "Fullscreen" "Toggles to full screen" \
" Spacebar" "Toggle Dwindle | Master Layout" "Hyprland Layout" \
" W" "Toggle float" "single window" \
" G" "Toggle all windows to float" "all windows" \
" SHIFT G" "Gamemode! All animations off" "" \
" H" "Launch this app" "" \
" E" "View or EDIT Keybinds, Settings, Monitor" "" \
"" "" "" \
"" "This window will auto-close in 60 secs" ""\
